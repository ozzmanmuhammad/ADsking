import { AuthSplitLayout } from 'src/layouts/auth-split';

// ----------------------------------------------------------------------

export default function Layout({ children }) {
  return <AuthSplitLayout>{children}</AuthSplitLayout>;
}
