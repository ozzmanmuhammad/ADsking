export const STORAGE_KEY = 'jwt_access_token';
