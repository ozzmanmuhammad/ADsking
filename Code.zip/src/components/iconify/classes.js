export const iconifyClasses = {
  root: 'mnl__icon__root',
  flag: 'mnl__icon__flag',
};
